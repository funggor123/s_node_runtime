#!/bin/bash

# Define
# Fix configurations
log_file_path="./log/"
default_host_port="8090"

echo "Please provide the host port of this $service_name (Default: $default_host_port): "
read host_port
if [ -z "$host_port" ] ;
then host_port="$default_host_port"
fi

echo "Please input x64_program_name (Default afs-x64): " 
read x64_program_name
if [ -z "$x64_program_name" ] ;
then x64_program_name="afs-x64"
fi
echo "Please input x64_program_path (Default: /ks/afs_1e/): " 
read x64_program_path
if [ -z "$x64_program_path" ] ;
then x64_program_path="/ks/afs_1e/"
fi


. ./make_json.sh
                                                                       
