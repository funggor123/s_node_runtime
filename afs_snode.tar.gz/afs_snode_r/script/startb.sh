#!/bin/bash

cd .. 

nohup ./main &

                                    
                                    
